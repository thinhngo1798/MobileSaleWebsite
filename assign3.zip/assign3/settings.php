<?php
      $host = "feenix-mariadb.swin.edu.au";
      $user = "s101766060";
      $pwd = "Thinh123";
      $sql_db = "s101766060_db";
?>